<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Variantes Covid</title>
</head>
<body>
    <h1>Lista de variantes de Covid</h1>
    <p> *Actualizado el dia 28 de enero*</p>
</body>
</html>
<?php /**PATH /Users/ulsa/Desktop/mi_proyecto/resources/views/variantes/index.blade.php ENDPATH**/ ?>